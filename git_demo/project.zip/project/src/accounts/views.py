
# views.py
from django.shortcuts import render, redirect
from django.contrib.auth.models import User ,auth
from django.contrib import messages
from .forms import RegistrationForm
from django.contrib.auth import authenticate, login
from .forms import LoginForm


def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            # Create the user
            User.objects.create_user(
                username=form.cleaned_data['username'],
                email=form.cleaned_data['email'],
                password=form.cleaned_data['password']
            )
            messages.success(request, "Registration successful! You can now log in.")
            return redirect('/')  # Redirect to login or another page
    else:
        form = RegistrationForm()

    return render(request, 'register.html', {'form': form})



def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                messages.success(request, "You have successfully logged in.")
                return redirect("/")  # Redirect to a home or dashboard page
            else:
                messages.error(request, "Invalid username or password.")
    else:
        form = LoginForm()
    
    return render(request, 'login.html', {'form': form})

def logout(request):
    auth.logout(request)
    return redirect("/")




# from django.shortcuts import render,redirect
# from django.contrib.auth.models import User ,auth

# # Create your views here.
# # from .models import Register
# from .forms import RegistrationForm

# def create_registration(request, *args, **kw):
#     if request.method == 'POST':
#         form = RegistrationForm(request.POST)
#         if form.is_valid():
#             username = request.POST.get('username')
#             email = request.POST.get('email')
#             password = request.POST.get('password')
#             user = User.objects.create_user(username=username, email=email, password=password)
#             form = RegistrationForm()
#             return redirect("/")
#     else:
#         form = RegistrationForm()
#     return render(request, 'register.html', {'form': form})

# from django.shortcuts import render ,redirect

# from django.contrib.auth.models import User ,auth
# from .forms import RegistrationForm

# # Create your views here.

# def create_registration(request):
#     if request.method == 'POST':
#         form = RegistrationForm(request.POST)
#         if form.is_valid():
#             form = RegistrationForm()
#             user = User.objects.create_user(username=form.username, email=form.email, password=form.password)
#             user.save()
#             return redirect("/")
#         else:
#             return render(request, "register.html", {"error": "Passwords do not match."})

#     return render(request,"register.html",{"form":form})


# def signin(request):
#     if request.method == 'POST':
#         username = request.POST.get('username')
#         password = request.POST.get('password')
#         user = auth.authenticate(username=username, password=password)
#         if user is not None:
#             auth.login(request, user)
#             return redirect("/carvilla")
#         else:
#             return render(request, "signin.html", {"error": "Invalid credentials."})
#     return render(request,"signin.html")

# def signout(request):
#     auth.logout(request)
#     return redirect("/carvilla")