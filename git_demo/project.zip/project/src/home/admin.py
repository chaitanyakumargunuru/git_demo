from django.contrib import admin

from .models import Topcars , cars
# Register your models here.

admin.site.register(Topcars)
admin.site.register(cars)