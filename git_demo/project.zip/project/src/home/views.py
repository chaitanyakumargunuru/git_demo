from django.shortcuts import render,redirect

from .models import Topcars,cars
# Create your views here.

def index(request, *args, **kwargs):
    
    top=Topcars.objects.all()
    return render(request, 'index.html',{'top':top})


def analogy(request):
    return render(request, 'analogy.html')

def comfort(request, *args, **kwargs):
    com=cars.objects.all()
    return render(request, 'comfort.html',{"comfort":com})

def go_to_sales(request, *args, **kwargs):
    if request.method=="POST":
        name=request.POST.get('car_name')
        car=cars.objects.filter(name=name)
        return render(request,'sale_1.html',{"cars":car})
    return render(request, 'sale_1.html')

def purchase(request, *args, **kwargs):
    if request.method=="POST":
        print(request.POST)
        name=request.POST.get('car_name')
        car=cars.objects.filter(name=name)
        return render(request,'purchase.html',{"cars":car})
    return render(request, 'purchase.html')

def show_analogy(request, *args, **kwargs):
    if request.method == 'POST':
        # Get the selected car from the form
        selected_car = request.POST.get('car')
        id_list=[]
        if selected_car in ("Sad","Happy","Angry","Surprised"):
            car=cars.objects.all()
            for i in car:
                if  selected_car.lower() == i.expression.lower():
                    id_list.append(i.expression)
            id_list = cars.objects.filter(expression__in=id_list)
        else:
            car=cars.objects.all()
            for i in car:
                if  selected_car.lower() == i.analogy.lower():
                    id_list.append(i.relative)
            id_list = cars.objects.filter(relative__in=id_list)
            # Redirect to the same page, passing the selected car as a URL parameter
        return render(request, 'analogy.html', {'selected_car_list': id_list,"selected_car": selected_car})

    # Get the selected car from the query parameter if it exists

    # Render the template with the selected car
    return render(request, 'analogy.html')