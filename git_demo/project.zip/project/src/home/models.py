from django.db import models

# Create your models here.

class Topcars(models.Model):
    name = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=20, decimal_places=2)
    image = models.ImageField(upload_to="pics")
    rank = models.PositiveIntegerField()
    release_date = models.DateField(blank=True)
    
class cars(models.Model):
    name = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=20, decimal_places=2)
    image = models.ImageField(upload_to="pics")
    release_date = models.DateField(blank=True)
    analogy = models.CharField(max_length=255)
    relative = models.TextField(blank = False)
    expression = models.CharField(max_length=255,default="null" ,blank=True)