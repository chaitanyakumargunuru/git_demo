from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path("analogy",views.analogy, name='analogy'),
    path("comfort",views.comfort, name='comfort'),
    path("sales",views.go_to_sales, name='sales'),
    path("show_analogy",views.show_analogy, name='show_analogy'),
   ]