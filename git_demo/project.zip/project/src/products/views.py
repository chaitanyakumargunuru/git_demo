from django.shortcuts import render

# Create your views here.

from . models import CarImages



def car_images(request):
    if request.method == "POST":
        car_name=request.POST.get("car_name")
        car = CarImages.objects.get(name=car_name)
        return render(request, "purchase.html", {"car": car})
    return render(request,"purchase.html",{"car":car})
        