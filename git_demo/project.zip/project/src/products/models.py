from django.db import models

# Create your models here.

class CarImages(models.Model):
    name= models.CharField(max_length=255)
    image= models.ImageField(upload_to='car_images/')
    front_view = models.ImageField(upload_to='car_images/')
    side_view = models.ImageField(upload_to='car_images/')
    rear_view = models.ImageField(upload_to='car_images/')
    top_view = models.ImageField(upload_to='car_images/')
    interior_1 = models.ImageField(upload_to='car_images/')
    interior_2 = models.ImageField(upload_to='car_images/')
    interior_3 = models.ImageField(upload_to='car_images/')
    interior_4 = models.ImageField(upload_to='car_images/')
    price = models.PositiveIntegerField()
    analogy = models.CharField(max_length=255)
    details = models.TextField()
    
    