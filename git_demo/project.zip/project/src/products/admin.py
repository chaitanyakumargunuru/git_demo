from django.contrib import admin

# Register your models here.
from .models import CarImages

admin.site.register(CarImages)