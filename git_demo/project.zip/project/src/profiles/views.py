# views.py
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Profile
from .forms import ProfileForm

@login_required
def profile(request):
    profile, created = Profile.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            return redirect('/')
    else:
        form = ProfileForm(instance=profile)
    return render(request, 'profile.html', {'form': form, 'user': request.user})

@login_required
def profile_view(request):
    # Get the user’s profile
    user_profile = Profile.objects.get(user=request.user)  # Assuming Profile model has a OneToOne relation with User

    # Pass profile data to the template
    context = {
        'user': request.user,
        'profile': user_profile
    }
    return render(request, 'profile_view.html', context)
